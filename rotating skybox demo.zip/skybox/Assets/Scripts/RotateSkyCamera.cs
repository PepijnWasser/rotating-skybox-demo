using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateSkyCamera : MonoBehaviour
{
    public Camera mainCam;
    public GameObject player;

    float counter = 0;

    public float rotationSpeed;
    public Vector3 rotationAxis;

    private void Update()
    {
        counter += Time.deltaTime;
        Quaternion rotationQuaternion = Quaternion.AngleAxis(counter * rotationSpeed, rotationAxis);
        Debug.Log(rotationQuaternion.eulerAngles.z);
        transform.rotation = rotationQuaternion;
    }
}
