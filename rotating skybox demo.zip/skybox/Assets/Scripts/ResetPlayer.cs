using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetPlayer : MonoBehaviour
{
    Vector3 startPos;
    public CharacterController controller;

    private void Start()
    {
        startPos = transform.position;    
    }

    // Update is called once per frame
    void Update()
    {
        if(this.gameObject.transform.position.y < -20)
        {
            controller.Move(-this.transform.position + startPos);
            this.gameObject.transform.position = startPos;
            Debug.Log("resetting");
        }
    }
}
