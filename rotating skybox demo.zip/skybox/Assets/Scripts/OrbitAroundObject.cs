using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbitAroundObject : MonoBehaviour
{
    public GameObject target;
    public float speed;

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(target.transform.position - this.transform.position, speed);
    }
}
